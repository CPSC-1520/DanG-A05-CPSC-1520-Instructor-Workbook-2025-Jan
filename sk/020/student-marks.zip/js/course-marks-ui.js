/* UI Notes:
    - Making some presumptions about styling being based on PicoCSS
    - <section id="courses">
        - The container to be populated with information on each course
    - <template id="course-shell">
        - A template for each course. This is "bare-bones" in that it contains a <details> element with placeholders for the course name and code. Individual evaluation items would need to be dynamically appended to this HTML.
        - For information on using this, see [A more involved example](https://developer.mozilla.org/en-US/docs/Web/API/Web_components/Using_templates_and_slots#a_more_involved_example)

    Here's an advanced example of the template, but with slots.
    ```html
        <template id="course-shell">
            <details>
                <summary><span class="course-code"></span> <span class="course-name"></span> &mdash; <span class="summary-marks"></span></summary>
                <section class="grid grid-col-4"></section>
                <hr />
            </details>
        </template>
    ```
*/
import { Course, EvaluationItem } from "./course-marks";

/**
 * Populates the element whose id is 'courses' with the DOM structure indicated by the template 'course-shell'
 * @param {Course[]} courses An array of Course objects
 */
const populateContent = function (courses) {
  courses = courses.map((x) => Course.fromJsonObject(x));
  console.log(courses);

  const template =
    document.getElementById("course-shell").content.firstElementChild;
  const container = document.getElementById("courses");
  courses.forEach((course) => {
    let element = template.cloneNode(true);
    element.querySelector(".course-code").innerHTML = course.code;
    element.querySelector(".course-name").innerHTML = course.name;

    let span = element.querySelector(".summary-marks");
    let space = document.createTextNode(" ");
    let mark = document.createElement("mark");
    mark.innerText = course.getTotalEarned() + " %";
    let small = document.createElement("small");
    small.innerText = `(remaining ${course.getTotalUnmarked()}% possible)`;
    span.appendChild(mark);
    span.appendChild(space);
    span.appendChild(small);

    let grid = element.querySelector(".grid");
    course.evaluations.forEach((item) => {
      grid.appendChild(createEvaluationItemElement(item));
    });

    container.appendChild(element);
  });
};

/**
 * Builds a HTMLDivElement with information from an evaluation item.
 * @param {EvaluationItem} evalItem Some evaluation item associated with a course
 * @returns {HTMLDivElement}
 */
const createEvaluationItemElement = function (evalItem) {
  let { name, weight, earned, possible } = evalItem;
  let earnedWeight = evalItem.getWeightedPercent();

  let text = `${
    earnedWeight === null ? "TBD" : `${earnedWeight} %`
  } - ${name} (${weight} %)`;
  let div = document.createElement("div");
  let textNode = document.createTextNode(text);
  div.appendChild(textNode);

  return div;
};

export { populateContent };
