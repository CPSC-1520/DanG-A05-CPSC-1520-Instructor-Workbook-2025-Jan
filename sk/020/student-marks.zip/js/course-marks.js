/**
 * Constructs a Course object with an empty array of evaluations.
 * @param {string} code The course code (e.g.: 'PROG-0101')
 * @param {string} name The course name (e.g.: 'JavaScript Fundamentals')
 */
const Course = function(code, name) {
  /** @type {string} */
  this.code = code;
  /** @type {string} */
  this.name = name;
  /** @type {EvaluationItem} */
  this.evaluations = [];

  /**
   * @return {number}
   */
  this.getTotalWeight = function () {
    return this.evaluations.reduce((sum, item) => sum + item.weight, 0);
  };

  /**
   * @return {number}
   */
  this.getTotalEarned = function () {
    let result = this.evaluations.filter(
      (item) => !isNaN(item.getWeightedPercent())
    );
    console.log(result.map((x) => x.getWeightedPercent()));
    result = result.reduce((sum, item) => sum + item.getWeightedPercent(), 0);
    return result;
  };

  /**
   * @return {number}
   */
  this.getTotalUnmarked = function () {
    let result = this.evaluations.filter((item) => item.getPercent() === null);
    result = result.reduce((sum, item) => sum + item.weight, 0);
    return result;
  };
}

/**
 * This function is intended for converting a plain object (such as one parsed from a JSON string) into a Course object.
 * @param {object} obj An object expected to match the structure of Course objcts
 * @returns Course
 */
Course.fromJsonObject = function(obj) {
    let course = new Course(obj.code, obj.name);
    obj.evaluations.forEach(item => {
        course.evaluations.push(new EvaluationItem(item.name, item.weight, item.earned, item.possible));
    });
    return course;
}

/**
 * Constructs an EvaluationItem object with or without details on the earned/possible points.
 * @param {string} name The name of the evaluation item (e.g.: 'Lab 1')
 * @param {number} weight The weight of the evaluation item within the course
 * @param {number | null} earned The points earned on the marked evaluation item
 * @param {number | null} possible The total possible points that can be earned on the evaluation item
 */
const EvaluationItem = function(name, weight, earned, possible) {
  /** @type {string} */
  this.name = name;
  /** @type {number} */
  this.weight = weight;

  /** @type {number | null} */
  this.earned = typeof earned === 'number' ? earned : null;
  /** @type {number | null} */
  this.possible = typeof possible === "number" ? possible : null;

  /**
   * @return {number | null}
   */
  this.getPercent = function () {
    let result = null;
    if (this.earned !== null && this.possible !== null) {
      result = (this.earned / this.possible) * 100;
    }
    return result;
  };

  /**
   * @return {number | null}
   */
  this.getWeightedPercent = function () {
    let result = null;
    let percent = this.getPercent();
    if (percent !== null) {
      result = (percent * this.weight) / 100;
    }
    return result;
  };
}

export { Course, EvaluationItem }
