import "@picocss/pico/css/pico.css";

import { populateContent } from "./course-marks-ui";
import { populateAbout } from "./about-ui";

// Processing begins here
fetch("./data/courses.json")
  .then((x) => x.json())
  .then(populateContent);

fetch("./ReadMe.md").then(response => response.text()).then(populateAbout);
